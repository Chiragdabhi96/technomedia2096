const express = require('express');
const app = express();
var bodyParser = require('body-parser');
var cors = require('cors');
require('dotenv').config();
require('./db/db');


let port = process.env.PORT;

app.use(bodyParser.json());
app.use(cors());

app.listen(port, () => {
    console.log("Server started at : " + port);
});

app.get('/', function (req, res) {
    res.send('Hello World!');
});

const user = require('./app/route/user.route');
app.use('/api/user',user);

const maintenance = require('./app/route/maintenance.route');
app.use('/api/maintenance',maintenance);
