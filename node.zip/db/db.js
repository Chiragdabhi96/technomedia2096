let mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/flat_swap',{ useUnifiedTopology: true });
mongoose.set('debug', false)

mongoose.connection.on('connected', ()=> {
    console.log('Connected to database');
});

mongoose.connection.on('error',(err) => {
    if(err){
        console.log('Error in Database connections : ' + err);
    }
})