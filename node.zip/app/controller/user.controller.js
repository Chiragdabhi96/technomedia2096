const userModel = require('../model/user.model');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

//create user
// exports.userIsLive = async (req, res) => {
//     try {
//         const isLive = await userModel.isLive
//         console.log(isLive);
//         if (isLive) {
//             res.json({ isLive: !isLive });
//             console.log(req);
//         }
//     } catch (e) {
//         res.json({ status: 412, message: e.message })
//     }
// }
// exports.create = async (req, res) => {
//     try {
//         const userExist = await userModel.findOne({email: req.body.email});
//         if (userExist) {
//             res.json({status: 412, message: "User is already exist with same email address."});
//         } else {
//             req.body.password = await bcrypt.hashSync(req.body.password);
//             req.body.username = req.body.name + Math.floor(1000 + Math.random() * 9000);
//             req.body['created_at'] = new Date();
//             var newUser = new userModel(req.body);
//             await newUser.save();
//             res.json({status: 200, message: "User created successfully."});
//         }

//     } catch (e) {
//         res.json({status: 412, message: e.message})
//     }
// }

// //user login
// exports.login = async (req, res) => {
//     try {
//         const userExist = await userModel.findOne({email: req.body.email, isDeleted: 0});
//         if (userExist) {
//             if (bcrypt.compareSync(req.body.password, userExist.password)) {
//                 let token = ({
//                     _id: userExist._id,
//                     email: userExist.email,
//                     name: userExist.name,
//                     username: userExist.username,
//                     gender: userExist.gender,
//                     phone_number: userExist.phone_number,
//                 });

//                 const tokenData = await jwt.sign({token}, process.env.SECRETKEY, {expiresIn: '1d'});
//                 res.json({status: 200, message: "Login Success.", token: tokenData});
//             } else {
//                 res.json({status: 412, message: "You have entered wrong password."});
//             }
//         } else {
//             res.json({status: 404, message: "Email not exist."});
//         }

//     } catch (e) {
//         res.json({status: 412, message: e.message})
//     }
// }

// //get all users
// exports.getUsers = async (req, res) => {
//     try {
//         const PAGE_SIZE = req.body.limit ? req.body.limit : 2;
//         const skip = req.body.page ? ((req.body.page - 1) * PAGE_SIZE) : 0;
//         var query = {
//             $and: [
//                 {isDeleted: false}
//             ]
//         };
//         if (req.body.search) {
//             query.$and.push({
//                 name: {'$regex': req.body.search}
//             });
//         }
//         if (req.body.phonenumber) {
//             query.$and.push({
//                 phone_number: {'$regex': req.body.phonenumber}
//             });
//         }
//         var userData = await userModel.aggregate([
//             {
//                 $match: query
//             },
//             { $sort: { "created_at": -1 } },
//             { $skip: skip },
//             { $limit: PAGE_SIZE }
//         ]);
//        const totalRecord =  await userModel.find({isDeleted: false}).count();
//         res.json({status: 200, message: "User list fetch successfully.", count: totalRecord, data: userData});
//     } catch (e) {
//         res.json({status: 412, message: e.message})
//     }
// }

// //get user by id
// exports.getUserById = async (req, res) => {
//     try {
//         var userData = await userModel.findOne({_id: req.params.id});
//         if (userData) {
//             res.json({status: 200, message: "get user successfully.", data: userData});
//         } else {
//             res.json({status: 404, message: "User not found."});
//         }
//     } catch (e) {
//         res.json({status: 412, message: e.message})
//     }
// }

// //edit user
// exports.editUser = async (req, res) => {
//     try {

//         var userData = await userModel.findById(req.body._id);

//         if (userData) {

//             userData.name = req.body.name ? req.body.name : userData.name,
//                 userData.gender = req.body.gender ? req.body.gender : userData.gender,
//                 userData.phone_number = req.body.phone_number ? req.body.phone_number : userData.phone_number,
//                 userData.updated_at = new Date()

//             const data = await userData.save();

//             res.json({status: 200, message: "User data updated successfully.", data: data});
//         } else {
//             res.json({status: 404, message: "User not found."});
//         }
//     } catch (e) {
//         res.json({status: 412, message: e.message})
//     }
// }

// //soft delete user
// exports.deleteUser = async (req, res) => {
//     try {
//         var userData = await userModel.findOne({_id: req.params.id});
//         if (userData) {
//             userData.isDeleted = 1;
//             await userData.save();
//             res.json({status: 200, message: "User deleted successfully."});
//         } else {
//             res.json({status: 404, message: "User not found."});
//         }
//     } catch (e) {
//         res.json({status: 412, message: e.message})
//     }
// }

