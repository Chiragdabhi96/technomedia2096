const maintenanceModel = require('../model/maintenance.model');

//isLive status
exports.userIsLive = async (req, res) => {
    try {
        const userData = await maintenanceModel.findOne()
        if (userData) {
            userData.isLive = req.body.isLive
            const data = await userData.save();
            res.json({ status: 200, message: 'Data updated', isLive: data.isLive });
        }
    } catch (e) {
        res.json({ status: 412, message: e.message })
    }
}

exports.getUserIsLive = async (req, res) => {
    try {
        const data = await maintenanceModel.findOne()
        if (data) {
            res.json({ status: 200, isLive: data.isLive });
        }
    } catch (e) {
        res.json({ status: 412, message: e.message })
    }
}

exports.userLogin = async (req, res) => {
    try {
        const userData = await maintenanceModel.findOne()
        if (userData) {
            const successStatus = req.body.password === userData.password ? true : false
            res.json({ status: 200, successStatus: successStatus, isLive: userData.isLive });
        }
    } catch (e) {
        res.json({ status: 412, message: e.message })
    }
}