const mongoose = require('mongoose');

const maintenanceSchema = mongoose.Schema({
    isLive: {
        type: Boolean,
        default: true
    },
    password: {
        type: String,
        default: 'admin@123'
    }
}, { collection: 'maintenance' });
module.exports = mongoose.model('maintenance', maintenanceSchema);