const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    // username : {
    //     type : String,
    //     required :true
    // },
    // gender : {
    //     type : String,
    //     enum : ['male', 'female', 'other']
    // },
    // phone_number : {
    //     type : String,
    //     required :true
    // },
    // email : {
    //     type : String,
    //     required :true
    // },
    // password : {
    //     type : String,
    //     required :true
    // },
    // isDeleted : {
    //     type : Boolean,
    //     default : false
    // },
    // created_at : {
    //     type : Date,
    //     required :true
    // },
    // updated_at : {
    //     type : Date
    // }
}, { collection : 'user'});
module.exports = mongoose.model('user', userSchema);