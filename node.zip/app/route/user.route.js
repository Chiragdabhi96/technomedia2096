
const express = require('express');
const router = express.Router();
const userController = require('../controller/user.controller');
//verify token
const {verifyToken} = require('../../services/verifyToken');

//validation modules
const {userLoginValidation, validate} = require('../../validation/validator/user.validator');

// router.post('/create-user', userController.create);
// router.post('/login', userLoginValidation(), validate, userController.login);
// router.post('/user-list', verifyToken, validate, userController.getUsers);
// router.get('/get-user/:id', verifyToken, validate, userController.getUserById);
// router.put('/edit-user', verifyToken, validate, userController.editUser);
// router.delete('/delete-user/:id', verifyToken, validate, userController.deleteUser);
//router.post('/user-isLive', userController.userIsLive);
module.exports = router;