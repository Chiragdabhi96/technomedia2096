
const express = require('express');
const router = express.Router();
const maintenanceController = require('../controller/maintenance.controller');
router.post('/user-isLive', maintenanceController.userIsLive);
router.get('/get-user-isLive', maintenanceController.getUserIsLive);
router.post('/user-login', maintenanceController.userLogin)
module.exports = router;