const { response } = require('express');
const {body, validationResult} = require('express-validator');
const validation = require("../constants/validationMessages");


//validate the user create value
const userCreateValidation = () => {
    return [
        body('name').trim(" ").not().isEmpty().withMessage(validation.user.nameRequired),
        body('gender').trim(" ").not().isEmpty().withMessage(validation.user.genderRequired),
        body('phone_number').trim(" ").not().isEmpty().withMessage(validation.user.phoneNumberRequired),
        body('email').trim(" ").not().isEmpty().withMessage(validation.user.emailRequired),
        body('email').isEmail().withMessage(validation.user.invalidEmail),
        body('password').trim(" ").not().isEmpty().withMessage(validation.user.passwordRequired)
    ]
    }

//validate the login value
const userLoginValidation = () => {
    return [
        body('email').trim(" ").not().isEmpty().withMessage(validation.user.emailRequired),
        body('email').isEmail().withMessage(validation.user.invalidEmail),
        body('password').trim(" ").not().isEmpty().withMessage(validation.user.passwordRequired),
    ]
}

//validate function will return the response of error
const validate = (req, res, next) => {
    const errors = validationResult(req);
    if(errors.isEmpty()) {
        return next()
    }
    const extractedErrors = []
    errors.array().map(err => extractedErrors.push({ [err.param] : err.msg, status : 412}));
    return res.json({  status : 422, errors : extractedErrors});
}

module.exports = {
    userLoginValidation,
    validate
}