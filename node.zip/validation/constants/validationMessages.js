exports.user = {
    "emailRequired" : "Email field can not be left blank",
    "passwordRequired" : "Password field can not be left blank",
    "invalidEmail" : "Email is not valid.",
    "nameRequired" : "Name field can not be left blank",
    "genderRequired" : "Gender field can not be left blank",
    "phoneNumberRequired" : "Phone number field can not be left blank"
 }